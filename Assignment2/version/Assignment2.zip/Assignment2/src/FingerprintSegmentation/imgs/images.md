Useful images
